import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class QRpage extends StatefulWidget {
  @override
  State<QRpage> createState() => _QRpageState();
}

class _QRpageState extends State<QRpage> {
  String _qrCode = "Scan a QR code"; // Default message before scanning

  // This function is called when a QR code is scanned
  void _onScan(BarcodeCapture barcode) {
    // setState(() {
    //   _qrCode = barcode.raw ??
    //       "No QR code detected"; // Update the UI with the scanned code
    // });
    print('Scanned QR code: ${barcode.raw}');
    // You can handle the QR code data here (e.g., navigate, show alert, etc.)
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('QR Code Scanner'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Container(
              height: 400, // Adjust height as needed
              width: 400, // Adjust width as needed
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(
                    70), // Rounded corners for the scanner
                border: Border.all(
                  color:
                      const Color.fromARGB(255, 209, 208, 208), // Border color
                  width: 3, // Border width
                ),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(70),
                child: MobileScanner(
                  onDetect: (barcode) {
                    if (barcode.raw != null) {
                      // Update the state with the scanned QR code value
                      _onScan(barcode);

                      // Show a snackbar with the scanned QR code
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                            content: Text('Scanned QR Code: ${barcode.raw}')),
                      );

                      // Log the scanned QR code value
                      log('Scanned QR Code: ${barcode.raw}');
                    }
                  },
                ),
              ),
            ),
          ),

          // Display the scanned QR code below the scanner view
          Text(
            "Scanned QR Code: $_qrCode", // Show the scanned QR code value
            style: TextStyle(fontSize: 20),
          ),
          SizedBox(height: 20), // Add some spacing
          // Optionally, show a message or another UI component
          Text("Congratulation! 500 points have been added to your wallet"),
        ],
      ),
    );
  }
}
