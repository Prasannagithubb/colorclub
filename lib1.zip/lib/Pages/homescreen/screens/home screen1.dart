import 'package:flutter/material.dart';
import 'package:new_one/Pages/homescreen/screens/QRpage.dart';

class Homepage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text('ListView Builder with Icons'),
        ),
        body: IconList(),
      ),
    );
  }
}

class IconList extends StatelessWidget {
  final List<IconData> icons = [
    Icons.qr_code,
    Icons.favorite,
    Icons.star,
    Icons.settings,
    Icons.account_circle,
    Icons.notifications,
    Icons.search,
    Icons.camera_alt,
    Icons.message,
    Icons.mail,
  ];

  // Function to handle the onPressed event for each icon
  void _onIconPress(BuildContext context, IconData icon) {
    switch (icon) {
      case Icons.qr_code:
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => QRpage()));
        break;
      case Icons.favorite:
        break;
      case Icons.star:
        break;
      case Icons.settings:
        break;
      case Icons.account_circle:
        break;
      case Icons.notifications:
        break;
      case Icons.search:
        break;
      case Icons.camera_alt:
        break;
      case Icons.message:
        break;
      case Icons.mail:
        break;
      default:
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        GridView.builder(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4,
            crossAxisSpacing: 20.0,
            mainAxisSpacing: 10.0,
          ),
          itemCount: icons.length,
          itemBuilder: (context, index) {
            return InkWell(
              onTap: () => _onIconPress(context, icons[index]),
              child: Card(
                color: const Color.fromARGB(255, 63, 202, 212),
                child: Center(
                  child: Icon(
                    icons[index],
                    color: Colors.white,
                    size: 30.0,
                  ),
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}
//  controller: _messagecontroller,
//                         decoration: InputDecoration(
//                           suffixIcon: PopupMenuButton<String>(
//                             icon: const Icon(Icons.arrow_drop_down),
//                             onSelected: (String value) {
//                               setState(() {
//                                 _messagecontroller.text = value;
//                               });
//                             },
//                             itemBuilder: (BuildContext context) {
//                               return Message.map((String messages) {
//                                 return PopupMenuItem<String>(
//                                   value: messages,
//                                   child: Text(
//                                     messages,
//                                     style: TextStyle(),
//                                   ),
//                                 );
//                               }).toList();
//                             },
//                           ),
