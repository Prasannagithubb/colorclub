// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a sw locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'sw';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
    "Mobilenumber": MessageLookupByLibrary.simpleMessage(
      "Weka Nambari ya Simu",
    ),
    "Sendotp": MessageLookupByLibrary.simpleMessage("Send OTP"),
    "address1": MessageLookupByLibrary.simpleMessage("Anwani 1"),
    "address2": MessageLookupByLibrary.simpleMessage("Anwani 2"),
    "city": MessageLookupByLibrary.simpleMessage("Jiji"),
    "country": MessageLookupByLibrary.simpleMessage("Nchi"),
    "didntrecivecode": MessageLookupByLibrary.simpleMessage(
      "Hukupokea nambari ya kuthibitisha?",
    ),
    "language": MessageLookupByLibrary.simpleMessage("Lugha"),
    "notificationvia": MessageLookupByLibrary.simpleMessage("Taarifa Kupitia"),
    "otpenter": MessageLookupByLibrary.simpleMessage(
      "Ingiza OTP iliyotumwa kwa simu yako",
    ),
    "otpverify": MessageLookupByLibrary.simpleMessage("Uthibitishaji wa OTP"),
    "register": MessageLookupByLibrary.simpleMessage("Sajili"),
    "resend": MessageLookupByLibrary.simpleMessage("Tuma tena"),
    "username": MessageLookupByLibrary.simpleMessage("Jina la mtumiaji"),
    "verify": MessageLookupByLibrary.simpleMessage("Verify"),
    "viagoogle": MessageLookupByLibrary.simpleMessage("Kupitia Google"),
    "whatsappno": MessageLookupByLibrary.simpleMessage("Nambari ya Whats App"),
    "zipcode": MessageLookupByLibrary.simpleMessage("Msimbo wa Eneo"),
  };
}
